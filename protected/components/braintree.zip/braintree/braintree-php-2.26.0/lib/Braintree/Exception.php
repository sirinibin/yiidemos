<?php
/**
 * super class for all Braintree exceptions
 *
 * @package    Braintree
 * @subpackage Exception
 * @copyright  2010 Braintree Payment Solutions
 */


/**
 * super class for all Braintree exceptions
 *
 * @package    Braintree
 * @subpackage Exception
 * @copyright  2010 Braintree Payment Solutions
 */
class Braintree_Exception extends Exception
{
}
