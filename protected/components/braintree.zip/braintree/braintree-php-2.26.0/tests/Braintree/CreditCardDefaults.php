<?php

class CreditCardDefaults
{
    const ISSUING_BANK = "NETWORK ONLY";
    const COUNTRY_OF_ISSUANCE = "USA";
}
