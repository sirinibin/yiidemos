#!/bin/bash

rake --trace
